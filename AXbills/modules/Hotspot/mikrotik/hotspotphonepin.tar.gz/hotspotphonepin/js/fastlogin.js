/**
 * Created by Anykey on 08.07.2015.
 */
if (QueryString.login != '') {
    var user_login = QueryString.login;
}

if (QueryString.password != '') {
    var user_pass = QueryString.password;
}

if (QueryString.fastlogin != '') {
    try {
		var fastLogin = QueryString.fastlogin.toLowerCase();
	} catch ( e ) {
		var fastLogin = 'false';
	}
}

if (fastLogin == 'true') {
    if (user_login != '' && user_pass != '') {
        doFastLogin(user_login, user_pass);
    }
}

function doFastLogin(username, password) {

    document.login.username.value = username;

    document.login.password.value = password;
    //alert ('user: ' + username +' pass: ' + password);
    $('#login').submit();

    return false;
}